package com.example.android.assistant.companionaction.ui

import androidx.lifecycle.ViewModel

class HyperlocalViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
