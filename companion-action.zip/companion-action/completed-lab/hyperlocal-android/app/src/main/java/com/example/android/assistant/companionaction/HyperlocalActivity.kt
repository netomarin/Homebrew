package com.example.android.assistant.companionaction

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.android.assistant.companionaction.ui.HyperlocalFragment
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.hyperlocal_fragment.*

class HyperlocalActivity : AppCompatActivity() {

    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private var mUserAccount: GoogleSignInAccount? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.hyperlocal_activity)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, HyperlocalFragment.newInstance())
                .commitNow()
        }

        val gso: GoogleSignInOptions = GoogleSignInOptions
            .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestIdToken(getString(R.string.server_client_id))
            .requestProfile().build()

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        // Checking if the user is authenticated or not to show the correct menu items
        if (GoogleSignIn.getLastSignedInAccount(this) == null) {
            //User not logged in, showing the sign in option
            menu?.findItem(R.id.logout)?.isVisible = false
            menu?.findItem(R.id.signin)?.isVisible = true
        } else {
            //User is authenticated, showing the logout option
            menu?.findItem(R.id.signin)?.isVisible = false
            menu?.findItem(R.id.logout)?.isVisible = true
        }

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.signin -> {
                googleSignIn()
                true
            }
            R.id.logout -> {
                logout()
                true
            }
            R.id.about -> {
                about()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    public override fun onStart() {
        super.onStart()

    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_SIGN_IN) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleGoogleSignIn(task)
        }
    }

    private fun handleGoogleSignIn(completedTask: Task<GoogleSignInAccount>) {
        try {
            mUserAccount = completedTask.getResult(ApiException::class.java)
            Snackbar.make(hyperlocal, "Authentication Successful.", Snackbar.LENGTH_SHORT).show()

            // Reading the token ID and sending to back-end server to store and use if needed
            var idToken: String = mUserAccount?.idToken!!
            TODO("Send the Token ID to the back-end using an API call")
        } catch (e: ApiException) {
            Log.w(TAG, "Google sign in failed", e)
            Snackbar.make(hyperlocal, "Authentication Failed.", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun about() {
        TODO("Create the about activity and launch it from here")
    }

    private fun googleSignIn() {
        val signInIntent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    private fun logout() {
        mGoogleSignInClient.signOut()
            .addOnCompleteListener(this, OnCompleteListener {
                Snackbar.make(hyperlocal, "User signed out.", Snackbar.LENGTH_SHORT).show()
            })
    }

    companion object {
        private const val TAG = "HyperlocalActivity"
        private const val RC_SIGN_IN = 9001
    }
}
