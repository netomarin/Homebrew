package com.hyperlocal.entities;

import java.util.ArrayList;
import java.util.HashMap;

public class Activity {
  private String id;
  private String title;
  private String description;
  private String details;
  private String date;
  private String startTime;
  private String endTime;
  private ArrayList<Object> categories;
  private String icon;
  public String image;
  public String website;
  public boolean active;
  public String city;
  private HashMap<String, HashMap<String, Object>> faq;

  public HashMap<String, HashMap<String, Object>> getFaq() {
    return faq;
  }

  public void setFaq(HashMap<String, HashMap<String, Object>> faq) {
    this.faq = faq;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getDetails() {
    return details;
  }

  public void setDetails(String details) {
    this.details = details;
  }

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public String getStartTime() {
    return startTime;
  }

  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }

  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }

  public String getIcon() {
    return icon;
  }

  public void setIcon(String icon) {
    this.icon = icon;
  }

  public ArrayList<Object> getCategories() {
    return categories;
  }

  public void setCategories(ArrayList<Object> categories) {
    this.categories = categories;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public String getWebsite() {
    return website;
  }

  public void setWebsite(String website) {
    this.website = website;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public Activity() {}
}
