package com.hyperlocal.apps;

// Add imports

import com.google.actions.api.App;
import com.google.actions.api.DialogflowApp;
import com.hyperlocal.entities.Activity;
import com.hyperlocal.entities.User;
import com.hyperlocal.exceptions.ResourceNotFoundException;
import com.hyperlocal.repository.ActivityRepository;
import com.hyperlocal.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@SpringBootApplication(scanBasePackages = {"com.*"})
@RestController
public class SpringBootHandler extends DialogflowApp {
  private static final Logger LOGGER = LoggerFactory.getLogger(SpringBootHandler.class);

  @Autowired
  private AoGWebhookApplication actionsApp;// = new AoGWebhookApplication();

  public static void main(String[] args) {
    SpringApplication.run(SpringBootHandler.class, args);
  }

  @Autowired private ActivityRepository activityRepo;
  @Autowired private UserRepository userRepo;

  /**
   *
   * @param httpHeaders
   * @return
   */
  @RequestMapping(value = "/", method = RequestMethod.GET)
  public String handleGet(@RequestHeader HttpHeaders httpHeaders) {
    return "Your App is running but to get the response to the Action, it must be a valid JSON POST request";
  }

  @RequestMapping(
      value = "/aog-webhook",
      method = RequestMethod.POST,
      consumes = "application/json",
      produces = "application/json")
  public String handlePost(@RequestBody String body, @RequestHeader HttpHeaders httpHeaders) {

    LOGGER.debug("Request Body: " + body);
    CompletableFuture<String> future =
        actionsApp.handleRequest(body, httpHeaders.toSingleValueMap());
    try {
      String response = future.get();
      LOGGER.info("Response: " + response);
      return response;
    } catch (InterruptedException e) {
      LOGGER.error("Error in App.handleRequest ", e);
      return "Error handling the request - " + e.getMessage();
    } catch (ExecutionException e) {
      LOGGER.error("Error in App.handleRequest ", e);
      return "Error handling the request - " + e.getMessage();
    }
  }

  @RequestMapping(value = "/api/activities", method = RequestMethod.GET)
  public ResponseEntity<?> getAllActivities(
      @RequestParam(value = "category_filters", required = false) List<String> categoryFilters,
      @RequestParam(value = "city", required = false) String city) {

    LOGGER.info("getAllActivities city:" + city);
    List<Activity> activities;
    try {
      activities =
          activityRepo.getAllActivities(
              Optional.ofNullable(categoryFilters).orElse(new ArrayList<String>()), city);
    } catch (Exception e) {
      throw new ResourceNotFoundException(e.getMessage());
    }
    return new ResponseEntity(activities, HttpStatus.OK);
    // return events;
  }

  /**
   * @param id
   * @return
   * @throws Exception
   */
  @RequestMapping(value = "/api/activities/{id}", method = RequestMethod.GET)
  public Activity getActivityById(@PathVariable("id") String id) throws Exception {
    Activity activity = activityRepo.getActivityById(id);
    if (activity == null) throw new ResourceNotFoundException("id-" + id);
    return activity;
  }

  /**
   *
   * @return
   * @throws Exception
   */
  @RequestMapping(value = "/api/users", method = RequestMethod.GET)
  public ResponseEntity<List<User>> getUsers() throws Exception {
    List<User> users = userRepo.getAllUsers();

    return new ResponseEntity(users, HttpStatus.OK);
  }

  /**
   *
   * @param id
   * @return
   * @throws Exception
   */
  @RequestMapping(value = "/api/users/{id}", method = RequestMethod.GET)
  public ResponseEntity<List<User>> getUsers(@PathVariable("id") String id) throws Exception {
    User user = userRepo.getUserById(id);

    if (user == null) throw new ResourceNotFoundException("id-" + id);
    return new ResponseEntity(user, HttpStatus.OK);
  }

  /**
   * (Optional) App Engine health check endpoint mapping.
   *
   * @see <a
   *     href="https://cloud.google.com/appengine/docs/flexible/java/how-instances-are-managed#health_checking"></a>
   *     If your app does not handle health checks, a HTTP 404 response is interpreted as a
   *     successful reply.
   */
  @RequestMapping(value = "/_ah/health", method = RequestMethod.GET)
  public String healthy() {
    // Message body required though ignored
    return "Still surviving.";
  }
}
