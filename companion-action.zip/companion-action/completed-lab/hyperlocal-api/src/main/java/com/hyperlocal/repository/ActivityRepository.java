package com.hyperlocal.repository;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.hyperlocal.entities.Activity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ActivityRepository {

  private @Autowired FirestoreConnection fsConn;
  private static final Logger LOGGER = LoggerFactory.getLogger(ActivityRepository.class);

  public List<Activity> getFilteredActivities(CollectionReference activitiesRef, String filter)
      throws Exception {
    ApiFuture<QuerySnapshot> query;
    Query categoryFilterQuery = activitiesRef.whereArrayContains("categories", filter);
    query = categoryFilterQuery.get();

    ArrayList<Activity> activities = new ArrayList<Activity>();
    for (DocumentSnapshot document : query.get().getDocuments()) {
      Activity a = document.toObject(Activity.class);
      a.setId(document.getId());
      activities.add(a);
    }
    return activities;
  }

  public List<Activity> getAllActivities(List<String> categoryFilters, String city)
      throws Exception {
    // asynchronously retrieve all users
    CollectionReference activitiesRef = fsConn.getDB().collection("activities");

    ArrayList<Activity> activities = new ArrayList<>();

    Query query = activitiesRef.limit(3);
    LOGGER.info("====== city =====" + city);
    if (city != null) {
      query = activitiesRef.whereEqualTo("city", city);
    }

    // for no filters
    if (categoryFilters.size() == 0) {
      ApiFuture<QuerySnapshot> querySnapshot = query.get();
      List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();
      for (QueryDocumentSnapshot document : documents) {
        Activity activity = document.toObject(Activity.class);
        activity.setId(document.getId());
        activities.add(activity);
      }
    } else {
      // for request with filters
      for (String filter : categoryFilters) {
        activities.addAll(getFilteredActivities(activitiesRef, filter));
      }
    }

    return activities;
  }

  public Activity getActivityById(String id) throws Exception {
    DocumentReference docRef = fsConn.getDB().collection("activities").document(id);

    // asynchronously retrieve the document
    ApiFuture<DocumentSnapshot> future = docRef.get();

    // future.get() blocks on response
    DocumentSnapshot document = future.get();
    if (document.exists()) {
      Activity a = document.toObject(Activity.class);
      a.setId(document.getId());
      return a;
    } else {
      System.out.println("No such document!");
    }
    return null;
  }

  public FirestoreConnection getFsConn() {
    return fsConn;
  }
}
