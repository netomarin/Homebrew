package com.hyperlocal.repository;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;

@Service
public class FirestoreConnection {
  private Firestore db;
  private FirebaseOptions options;
  private static final Logger LOGGER = LoggerFactory.getLogger(FirestoreConnection.class);


  public FirestoreConnection() throws IOException {
    LOGGER.info("=====================INITIALIZING FirebaseRepository=====================");

    // Use a service account
    //try {
      InputStream in = getClass().getResourceAsStream("/service_account.json");
      GoogleCredentials credentials = GoogleCredentials.fromStream(in);
      FirebaseOptions options = new FirebaseOptions.Builder().setCredentials(credentials).build();
      LOGGER.info(FirebaseApp.getApps().toString());
      if (FirebaseApp.getApps().size() == 0) {
        FirebaseApp.initializeApp(options);
      }

      this.db = FirestoreClient.getFirestore();
      LOGGER.info("====THIS.DB =====" + this.db);

/*    } catch (Exception e) {
      LOGGER.info(e.getMessage());
      LOGGER.info(e.getStackTrace().toString());
    }*/
  }

  public Firestore getDB() {
    return db;
  }
}
