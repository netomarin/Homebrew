package com.hyperlocal.entities;

import com.google.cloud.firestore.DocumentReference;

import java.util.List;

public class User {
  private String email;
  private String name;
  private String id;
  private String location;
  private List<String> bookmarks;

/*  public DocumentReference getEvents_ref() {

  public DocumentReference getEvents_ref() {
>>>>>>> 6a3d787e89f748f2acf16756658bf1b50053fead
    return events_ref;
  }

  public void setEvents_ref(DocumentReference events_ref) {
    this.events_ref = events_ref;
  }

  private DocumentReference events_ref;


  public String getId() {
    return id;
  }*/

  public void setId(String id) {
    this.id = id;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public List<String> getBookmarks() {
    return bookmarks;
  }

  public void setBookmarks(List<String> bookmarks) {
    this.bookmarks = bookmarks;
  }

  public User() {}
}
