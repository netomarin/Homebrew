package com.hyperlocal.apps;

// Add imports

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.actions.api.ActionRequest;
import com.google.actions.api.ActionResponse;
import com.google.actions.api.DialogflowApp;
import com.google.actions.api.ForIntent;
import com.google.actions.api.response.ResponseBuilder;
import com.google.actions.api.response.helperintent.SignIn;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.actions_fulfillment.v2.model.Location;
import com.google.api.services.actions_fulfillment.v2.model.UserProfile;
import com.hyperlocal.entities.Activity;
import com.hyperlocal.repository.ActivityRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.MessageFormat;
import java.util.Collections;
import java.util.ResourceBundle;

/**
 * Represents an Actions on Google Application for DialogFlow. To learn more
 * https://github.com/actions-on-google/actions-on-google-java
 */
@Service
public class AoGWebhookApplication extends DialogflowApp {
  private static final Logger LOGGER = LoggerFactory.getLogger(AoGWebhookApplication.class);
  private static final String[] SUGGESTIONS =
      new String[] {"confirmation", "date time", "permissions", "place", "sign in"};
  private static final String[] SUGGESTIONS_FAQ =
      new String[] {
        "is there wifi?", "is there food?", "is it wheelchair easy?", "are pets allowed?"
      };

  private Environment env;
  @Autowired private ActivityRepository activityRepo;

  @Value("${clientIdAoG}")
  private String clientIdAoG;

  @Value("${hyperlocal_api_url}")
  private String hyperlocalApiUrl;

  private ObjectMapper mapper = new ObjectMapper();

  @ForIntent("Welcome Intent")
  public ActionResponse welcome(ActionRequest request) {
    LOGGER.info("Welcome intent start.");
    ResponseBuilder responseBuilder = getResponseBuilder(request);
    responseBuilder.add("Welcome to Hyperlocal.");

    LOGGER.info("Welcome intent end.");

    return responseBuilder.build();
  }

  @ForIntent("Start Signin")
  public ActionResponse text(ActionRequest request) {
    ResponseBuilder rb = getResponseBuilder(request);
    return rb.add(new SignIn().setContext("To get your account details")).build();
  }

  @ForIntent("actions.intent.SIGN_IN")
  public ActionResponse getSignInStatus(ActionRequest request) {
    ResponseBuilder responseBuilder = getResponseBuilder(request);
    if (request.isSignInGranted()) {
      GoogleIdToken.Payload profile = getUserProfile(request.getUser().getIdToken());
      responseBuilder.add(
          "I got your account details, "
              + profile.get("given_name")
              + ". What do you want to do next?");
    } else {
      responseBuilder.add("I won't be able to save your data, but what do you want to do next?");
    }
    return responseBuilder.build();
  }

  @ForIntent("Get my email")
  public ActionResponse getMyEmail(ActionRequest request) {
    GoogleIdToken.Payload profile = getUserProfile(request.getUser().getIdToken());
    ResponseBuilder responseBuilder = getResponseBuilder(request);
    responseBuilder.add(profile.getEmail());
    return responseBuilder.build();
  }

  private GoogleIdToken.Payload getUserProfile(String idToken) {
    GoogleIdToken.Payload profile = null;
    try {
      profile = decodeIdToken(idToken);
    } catch (Exception e) {
      LOGGER.error("error decoding idtoken");
      LOGGER.error(e.toString());
    }
    return profile;
  }

  @ForIntent("actions_intent_permission")
  public ActionResponse handlePermissionResponse(ActionRequest request) {
    ResponseBuilder responseBuilder = getResponseBuilder(request);
    ResourceBundle rb = ResourceBundle.getBundle("resources", request.getLocale());

    boolean havePermission = request.isPermissionGranted();
    String response;
    if (havePermission) {
      UserProfile userProfile = request.getUser().getProfile();
      if (userProfile != null) {
        response =
            MessageFormat.format(
                rb.getString("permission_response_success_1"), userProfile.getDisplayName());
      } else {
        response = rb.getString("permission_response_success_2");
      }
      Location location = request.getDevice().getLocation();
      if (location != null) {
        request.getConversationData().put("location", location);
        response +=
            MessageFormat.format(
                rb.getString("permission_response_location_1"), location.getCity());
      }
    } else {
      response = rb.getString("permission_response_location_2");
    }

    responseBuilder.add(response).addSuggestions(SUGGESTIONS);

    return responseBuilder.build();
  }

  @ForIntent("Tell me about an event")
  public ActionResponse tellMeAboutAnEvent(ActionRequest request) {
    LOGGER.info("tellMeAboutAnEvent start.");

    ResponseBuilder responseBuilder = getResponseBuilder(request);
    ResourceBundle rb = ResourceBundle.getBundle("resources", request.getLocale());
    String activityStr = request.getParameter("activity").toString();
    String activityNotFound = "Unfortunately " + (activityStr.isEmpty() ? "this activity" : activityStr) +
            " is not available at the moment. You can ask me about another activity, " +
            "I might have more advice.";
    LOGGER.info("activityStr: " + activityStr);

    if (activityStr.isEmpty()) {
      responseBuilder.add(activityNotFound);
      return responseBuilder.build();
    }

    RestTemplate restTemplate = new RestTemplate();
    HttpHeaders headers = new HttpHeaders();
    headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);

    LOGGER.info("hyperlocalApiUrl: " + hyperlocalApiUrl);

    UriComponentsBuilder builder =
            UriComponentsBuilder.fromHttpUrl(hyperlocalApiUrl)
                    .path("/api/activities/")
                    .path(activityStr);

    LOGGER.info(builder.toUriString());


    try {
      ResponseEntity<Activity> activity =
              restTemplate.exchange(
                      builder.build().encode().toUri(),
                      HttpMethod.GET,
                      null,
                      new ParameterizedTypeReference<Activity>() {});
      if (activity.getStatusCode().is2xxSuccessful()) {
        Activity activityObj = (Activity)activity.getBody();
        responseBuilder.getConversationData().put("activity", activityObj);
        responseBuilder.add("Hi! I can answer FAQs about " + activityObj.getTitle() + ". So, what’s your question?");
        responseBuilder.addSuggestions(SUGGESTIONS_FAQ);
      } else {
        responseBuilder.add(activityNotFound);
      }
    } catch(Exception e) {
      responseBuilder.add(activityNotFound);
    }
    return responseBuilder.build();

  }

  @ForIntent("FAQ Activity")
  public ActionResponse faqActivity(ActionRequest request) {
    LOGGER.info("faqActivity start.");
    ResponseBuilder responseBuilder = getResponseBuilder(request);
    ResourceBundle rb = ResourceBundle.getBundle("resources", request.getLocale());

    Activity activity = (Activity)request.getConversationData().get("activity");
    String category1 = (String) request.getParameter("category1");
    String category2 = (String) request.getParameter("category2");

    LOGGER.info("Activity: " + activity.getTitle());
    LOGGER.info("FAQ1: " + category1);
    LOGGER.info("FAQ2: " + category2);

    responseBuilder.add("Test2!");
    return responseBuilder.build();
  }



  private GoogleIdToken.Payload decodeIdToken(String idTokenString)
      throws GeneralSecurityException, IOException {

    HttpTransport transport = GoogleNetHttpTransport.newTrustedTransport();
    JacksonFactory jsonFactory = JacksonFactory.getDefaultInstance();
    GoogleIdTokenVerifier verifier =
        new GoogleIdTokenVerifier.Builder(transport, jsonFactory)
            // Specify the CLIENT_ID of the app that accesses the backend:
            .setAudience(Collections.singletonList(clientIdAoG))
            .build();
    GoogleIdToken idToken = verifier.verify(idTokenString);
    return idToken.getPayload();
  }
}
