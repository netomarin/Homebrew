package com.hyperlocal.repository;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.hyperlocal.entities.Activity;
import com.hyperlocal.entities.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class UserRepository {

  private @Autowired FirestoreConnection fsConn;
  private static final Logger LOGGER = LoggerFactory.getLogger(UserRepository.class);

  public List<User> getAllUsers() throws Exception {
    // asynchronously retrieve all users
    CollectionReference usersRef = fsConn.getDB().collection("users");

    ArrayList<User> users = new ArrayList<>();
    Query query = usersRef.limit(10);

    ApiFuture<QuerySnapshot> querySnapshot = query.get();
    List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();
    for (QueryDocumentSnapshot document : documents) {
      User u = document.toObject(User.class);
      u.setId(document.getId());
      users.add(u);
    }
    return users;
  }

  public User getUserById(String id) throws Exception {
    DocumentReference docRef = fsConn.getDB().collection("users").document(id);
    // asynchronously retrieve the document
    ApiFuture<DocumentSnapshot> future = docRef.get();

    // future.get() blocks on response
    DocumentSnapshot document = future.get();
    if (document.exists()) {
      //User u = document.toObject(User.class);
      User u = new User();
      u.setId(document.getId());

      DocumentReference docRef2 = ((DocumentReference)document.get("events_ref"));
      ApiFuture<DocumentSnapshot> future2 = docRef2.get();
      DocumentSnapshot document2 = future2.get();
      if (document2.exists()) {
        LOGGER.info((document2.toObject(Activity.class)).city);
      }


      //LOGGER.info(fsConn.getDB().document( (DocumentReference)document.get("events_ref")).getId());
      return u;
    } else {
      System.out.println("No such document!");
    }
    return null;
  }

  public FirestoreConnection getFsConn() {
    return fsConn;
  }
}
