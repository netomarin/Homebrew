package com.hyperlocal.intents;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyperlocal.repository.ActivityRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

/**
 * Represents all intents related to FAQ Hyperlocal Action. To learn more about Actions on Google
 * https://github.com/actions-on-google/actions-on-google-java
 */
public class FaqIntents {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(FaqIntents.class);
  private static final String[] SUGGESTIONS =
      new String[] {"confirmation", "date time", "permissions", "place", "sign in"};
  @Autowired private ActivityRepository eventRepo;

  @Value("${clientIdAoG}")
  String clientIdAoG;

  @Value("${project_id}")
  String projectId;

  private ObjectMapper mapper = new ObjectMapper();
}
