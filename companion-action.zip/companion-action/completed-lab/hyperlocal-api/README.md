SpringBoot REST API and Actions on Google Webhook
=================================================

Hyperlocal API (REST API + AoG Webhook) serves for two purposes.

@TODO - add image here

### Getting Started



### Requirements

* Service Account with access to FireStore saved under src/main/resources/service_account.json.
* Create a Google App Engine (GAE) App

Execute the following command to create your first GAE:

```bash
$ gcloud app create
```

* Create a Firestore Database

This database will be stored all the entities required by the API. Follow these steps to create it:
Go to Database in Firestore




### Start this App Locally
This app can run locally for development purposes and deployed to any environment that supports deploying a Java Web Container.


The following command will run the app locally on port 8080:
```bash
$ ./mvnw -DskipTests spring-boot:run

```

### Test

@TODO cURL and OpenAPI Spec.


### Deploy to App Engine

```bash
$ ./mvnw -DskipTests clean appengine:deploy
```

